from .models import User, Profile
from django.contrib.auth.password_validation import validate_password
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

class ProfileUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ('first_name', 'last_name', 'phone', 'image')
        extra_kwargs = {'image': {'default': 'user-default.png', 'required': False}}
        partial = True

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email')

class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        
        token['first_name'] = user.profile.first_name
        token['last_name'] = user.profile.last_name
        token['username'] = user.username
        token['email'] = user.email
        token['image'] = str(user.profile.image)
        return token
    
class AdminLoginSeializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):    
        token = super().get_token(user)

        if user.is_superuser == False:
            token['access_token'] = None
            token['refresh_token'] = None
            token['message'] = "User is not admin"
        else:
            token['first_name'] = user.profile.first_name
            token['last_name'] = user.profile.last_name
            token['phone'] = user.profile.phone
            token['username'] = user.username
            token['email'] = user.email
            token['image'] = str(user.profile.image)
            
        return token


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = User
        fields = ('email', 'username', 'password', 'password2')

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError(
                {"password": "Password fields didn't match."})

        return attrs

    def create(self, validated_data):
        user = User.objects.create(
            username=validated_data['username'],
            email=validated_data['email']

        )

        user.set_password(validated_data['password'])
        user.save()

        return user